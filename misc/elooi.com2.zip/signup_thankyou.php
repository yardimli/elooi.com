<?php $page="signup-thankyou"; ?>
<?php include("ortak-header.php"); ?>

<div class="banner2">
<h2>CloudofVoice</h2>
</div>
<div class="content-main " >

	
<br><br>

  <h2><strong>Welcome to Elooi cloudofvoice!</strong></h2>
  <br><br>
  <h3>cloudofvoice helps you listen to the world around you. Hear friends, and Talk to everyone.</h3>
  <br>
  Thank You! <br>
  you are now a proud member of Elooi!<br>
  Click to <a href="signin.php">sign in</a>.
  </h3>



<br><br><br><br>




<?php include("ortak-fotter.php"); ?>


