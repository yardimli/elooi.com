
<?php
$consumer_key = 'Your_Key';
$consumer_secret = 'Your_SecretKey';
?>


