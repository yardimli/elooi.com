
			<div class="clear"></div>
			
		</div>
	</div>
	
 	<div id="footer">
		<div class="container_12">
			<div class="fotter_text alpha">
				<h5>About Us</h5>
				<a href="http://elooi.com/about">About</a><br>
				<a href="http://elooi.com/blog">Blog</a><br>
				<a href="http://elooi.com/contact">Contact</a><br>
			</div>
			<div class="fotter_text">
				<h5>Support</h5>
				<a href="http://elooi.com/help">Help</a><br>
				<a href="http://elooi.com/developers">Developers</a><br>
			</div>
			<div class="fotter_text">
				<h5>Legal</h5>
				<a href="http://elooi.com/privacy">Privacy</a><br>
				<a href="http://elooi.com/tos">Terms</a>
			</div>

			<div class="clear"></div>
			<div class="mb40"></div>
			
			<div class="fotter_text alpha omega">
				© 2014 <a href="http://elooi.com/">Elooi</a>, - A <a href="http://www.elorobotics.com/" title="Go to elorobotics.com">Elo Robot</a> Ltd. Company<br>
			</div>
			<div class="clear"></div>
			
		</div>
	</div>	
</div>
<div id="lb"></div>


  <fieldset id="location-popup">
	<input type="hidden" name="op" value="signin_popup">
      <label for="city">Location</label>
      <input id="city" name="city" value="" tabindex="4" type="text">
      </p>
	  <a href="#" onClick="javascript: jQuery('#location-str').html('Location: '); jQuery('#myLocation').val('none'); $('.location-menu').removeClass('menu-open'); $('fieldset#location-popup').hide(); return false;">Dont use location</a>
  </fieldset>

</body></html>