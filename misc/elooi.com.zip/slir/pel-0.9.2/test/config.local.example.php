<?php
/* You can define the path to SimpleTest here, or you can let PEL
 * search for it by walking up the directory tree. */
define('SIMPLE_TEST', '/usr/share/php/');