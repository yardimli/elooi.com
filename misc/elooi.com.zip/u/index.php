<?php

header( "Location: http://elooi.com/index.php" ) ;
exit();

?>